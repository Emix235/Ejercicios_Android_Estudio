# Apollo Music Player

Apollo-Music is a fork from CyanogenMod's <a href="https://github.com/adneal/Apollo-CM">Apollo<a/> music app supporting Android 4.1+

## What's new

- integrated equalizer
- playlist with the most listened songs
- new media playback notification


## Screenshots
<img src="/fastlane/metadata/android/en-US/images/phoneScreenshots/img1.jpg" width="200"/> <img src="/fastlane/metadata/android/en-US/images/phoneScreenshots/img2.jpg" width="200"/> <img src="/fastlane/metadata/android/en-US/images/phoneScreenshots/img3.jpg" width="200"/> <img src="/fastlane/metadata/android/en-US/images/phoneScreenshots/img4.jpg" width="200"/>
